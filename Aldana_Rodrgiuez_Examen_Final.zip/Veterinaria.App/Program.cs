using System;
using System.Collections.Generic;
using Veterinaria.Modelos;

namespace Veterinaria.App
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Mascota> mascotas = new List<Mascota>();

            Console.WriteLine("Sistema de gestión de mascotas - Clínica Veterinaria");
            // Lógica a implementar por el estudiante
        }
    }
}
