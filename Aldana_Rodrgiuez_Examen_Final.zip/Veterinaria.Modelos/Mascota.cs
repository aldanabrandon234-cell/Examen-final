namespace Veterinaria.Modelos
{
    public class Mascota
    {
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public int Edad { get; set; }
        public string Propietario { get; set; }
        public double Peso { get; set; }
    }
}
